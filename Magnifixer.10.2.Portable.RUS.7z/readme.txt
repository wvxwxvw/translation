
 Magnifixer - это утилита для увеличения области экрана.
 Показывает область экрана под курсором мыши в отдельном окне
 с заданным вами увеличением.

 Некоторые возможности:
 - Коэффициент увеличения до x40
 - Окно программы можно переместить в любое место экрана
 - Поддержка второго монитора
 - Сглаживание
 - Негативное отображение увеличиваемой области
 - Отслеживание текстового курсора
 - Заморозка области просмотра
 - Снимок области в буфер обмена
 - Функция «Поверх других окон»
 - Получение цвета пиксела под курсором (в HTML или RGB кодах)
 - Значок в трее (фоновый режим)
 - Сохранение большинства настроек

 *********************************************************************

 Перевод Magnifixer 10.2 portable, выполнен - wvxwxvw
 Поместить файлы из архива рядом с MagnifixerPortable.exe
 Прямая ссылка для загрузки портативной версии:
 http://www.blacksunsoftware.com/downloads/MagnifixerPortable.zip
 Файл Del.Install.Magnifixer.reg удаляет из реестра следы установочной версии.

 *********************************************************************

 Magnifixer 10.2 Release Notes - April 2021

 Platform: Windows XP/Vista/Win7/Win8/Win10.

 Copyright 2002-2019 Blacksun Software, All rights reserved.
 Internet: http://www.blacksunsoftware.com
 Support : support@blacksunsoftware.com

 *********************************************************************
 FEATURES
 *********************************************************************
 - Adjustable zoom factor - Up to 40x Magnification
 - Dual monitor supported
 - Smoothing for better readability
 - Cursor tracking or fixed location view
 - Stay-on-top window option
 - Color Display (HTML or RGB mode)
 - Most settings are saved and reused
 - Very simple and intuitive interface
 - System tray utility
 - Uninstall option

 *********************************************************************
 HISTORY
 *********************************************************************
version 10.2 : released April 2021
- ( Added ) Shortcut added for 'Stay on Top'  (Ctrl-Space)

version 10.1 : released November 2020
- ( Added ) Grid now allows frame sizes of 1, 5, 10, 20 or 50 pixels
- ( Fixed ) Cursor display in Fixed Location mode.

version 10.0 : released January 2020
- (Changed) 64 bit version
- (Changed) Smaller window size possible
- (Changed) Smoothen image procedure changed
- ( Fixed ) Problem with Monitor scaling fixed

version 6.3 : released June 2018
- ( Fixed ) Error with multiple non-aligned screens fixed

version 6.2 : released May 2018
- ( Fixed ) Follow caret option could not be disabled

version 6.1 : released February 2017
- ( Fixed ) 'Stay in System tray' bug fixed

version 6.0 : released February 2017
- Magnifixer stays active in system tray after screen is closed
- Left click on icon can show/hide program
- Popup menu items disabled when extra screens active
- Extra menu item to allow automatic run on startup
- Added some optional command line parameters
- Install procedure improved
- Close button added on panel
- Transparency added as command line parameter

version 5.1 : released August 2016
- (changed) Bug fixed storage settings

version 5.0 : released July 2016
- (changed) New Development Environment
- (changed) Upgraded components

version 4.0 : released April 2014
- (changed) Panel Color changed
- (changed) System components changed
- (changed) Dev. environment upgraded
- ( added ) Portable version created

version 3.4 : released November 2013
- (changed) UI font updated

version 3.3 : released September 2013
- ( added ) Popup menu added to reset default window size & position
- ( added ) Popup menus added to copy current screen coordinates or color code

version 3.2 : released December 2012
- ( fixed ) Fixed window position on multiple screen setup
- (changed) One instance limit removed
- (changed) Menu layout changed

version 3.1 : released Janary 2012
- ( added ) Minimum Magnifier windows size has been reduced
- ( added ) Left mousebutton does not show popup window anymore in system tray
- ( fixed ) Bug with 17x zoom through menu fixed
- (changed) Crosshair color is red when grid is enabled.

version 3.0 : released October 2010
- ( added ) Copy magnified screen to clipboard (CTRL-C)
- ( added ) Systemwide shortcut added to call magnifier (CTRL-G)
- ( added ) Shortcut added to enable/disable Magnifier (CTRL-E)
- ( added ) Check for updates added
- ( added ) Additional frequencies added for better tuning
- ( fixed ) Performance improved for aero on Vista and Win 7

version 2.3 : released March 2009
- ( fixed ) Shutdown when minimized caused startup problem

version 2.2 : released December 2008
- ( added ) Option to magnify a fixed area of screen
- ( fixed ) Magnifixer window is transparent on XP (does not work on Vista)

version 2.1 : released June 2008
- ( fixed ) Cursor hotspot correctly used
- ( fixed ) Flicker removed 
- (changed) additional display frequency added (30 times/sec)

version 2.0 : released Januari 2008
- (changed) performance improvement
- (changed) Maximum zoom level increased to 40 (instead of 15)
- ( added ) Zoom level can be changed with mouse scroll wheel
- ( added ) Zoom window can be smoothed for better readability.
- ( fixed ) Dual Monitor Support (also negative coordinates)

version 1.6 : released June 2007
- ( added ) Dual Monitor Support.

version 1.5 : released May 2007
- ( fixed ) Magnification factor is saved correctly.

version 1.4 : released June 2006
- ( added ) Inverted Display for maximum readability.
- ( added ) Cursor coordinates added to toolbar.
- ( added ) Titlebar is hidden (double-click to show).
- ( fixed ) Doubleclick problem when cursor is shown.
- ( fixed ) Minimum size constraints added.
- (changed) Moved Magnifixer to the system tray area.

version 1.3 : released November 2004
- ( added ) Adjustable speed settings.
- ( added ) Optional Cursor Display.

version 1.0 : released May 2003
- Initial Release
