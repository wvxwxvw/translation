
<!--
	Russian localization for Notepad++ 8.2
	last modified: 220112 by wvxwxvw
		Без раздражающего сКаКаНиЯ ТеКсТа и лишних символов.
		В комплекте, выравненные с русским, английский и немецкий
-->

Перевод contextMenu от DmitryFedorov, дополнил, убрал
сКаКаНиЕ ТеКсТа и привел в соответствие со своим переводом.

https://github.com/wvxwxvw/translation