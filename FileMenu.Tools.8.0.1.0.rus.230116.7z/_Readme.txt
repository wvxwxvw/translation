
Language=Russian (Россия)
Product=FileMenu Tools
Version=8.0.1.0
LastUpdated=230116
Author=wvxwxvw

https://github.com/wvxwxvw/translation