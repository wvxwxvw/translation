
	Russian localization for Notepad++
		Без раздражающего сКаКаНиЯ ТеКсТа и лишних символов.
		В комплекте, английский языковой файл, выровненный с русским
		и переведенный contextMenu.xml

https://github.com/wvxwxvw/translation