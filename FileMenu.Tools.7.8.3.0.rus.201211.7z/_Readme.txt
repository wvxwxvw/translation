
Language=Russian (Россия)
Product=FileMenu Tools
Version=7.8.3
LastUpdated=201211
Author=wvxwxvw

https://github.com/wvxwxvw/translation