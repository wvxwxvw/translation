
https://github.com/wvxwxvw/translation

Кинуть папку и файл в корень Notepad3, подтвердить перезапись.
В grepWinNP3 >> Settings >> Выбрать "Русский (wvxwxvw) [ru-RU]"