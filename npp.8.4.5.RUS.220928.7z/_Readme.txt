
<!--
	Russian localization for Notepad++
		Без раздражающего сКаКаНиЯ ТеКсТа и лишних символов.
		В комплекте, английский языковой файл выровненный с русским
-->

Перевод contextMenu от DmitryFedorov, дополнил, убрал
сКаКаНиЕ ТеКсТа и привел в соответствие со своим переводом.

https://github.com/wvxwxvw/translation