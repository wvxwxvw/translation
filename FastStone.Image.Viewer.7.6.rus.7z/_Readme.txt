
Перевод:
EmailZipEXE.bin - SFX распаковщик, получить можно при отправке по почте
(отправлять не обязательно, можно сохранить в папку),
FSViewer.RUS - сборка переведенных ресурсов (собственно сам перевод),
FSViewerHelp.chm - переведенная справка от официального перевода (неполная),
ZipDll.dll - диалог ввода пароля архива для ZIP.

Инструкция:
	Закрыть FS Image Viewer,
	Удалить из папки с FS Image Viewer подпапку "Languages",
	Кинуть в папку с FS Image Viewer желаемые (или все) файлы,
	Запустить FS Image Viewer.

Может не работать на Windows 10-11 и со всякими типа-антивирусными поделками.
В первом случае можно попробовать -
https://docs.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-search-order?redirectedfrom=MSDN
Во втором случае можно перенести ресурсы из FSViewer.RUS в исполняемый файл,
например ресторатором.

wvxwxvw