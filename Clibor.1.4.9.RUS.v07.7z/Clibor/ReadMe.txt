=============================
 Clibor
=============================
ver 1.4.9_en1
AppDeveloper Amuns
E-mail amunsclr@gmail.com
HP     http://www.amunsnet.com/
Manual http://www.amunsnet.com/soft/clibor-en.html
