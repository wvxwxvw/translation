
Language=Russian (Россия)
Product=FileMenu Tools
Version=7.8.2
LastUpdated=201116
Author=wvxwxvw

https://github.com/wvxwxvw/translation