
Language=Russian (Россия)
Product=FileMenu Tools
Version=7.8.4
LastUpdated=210318
Author=wvxwxvw

https://github.com/wvxwxvw/translation