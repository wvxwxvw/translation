﻿======================================================================
                   FastCopy  ver4.0.4                   2022/02/02
                                                 SHIROUZU Hiroaki
                                                 FastCopy Lab, LLC.
======================================================================

	FastCopy is the Fastest Copy/Delete Software on Windows.

	It can copy/delete unicode and over MAX_PATH(260byte) pathname files.

	It always run by multi-threading.

	It don't use MFC, it is compact and don't requre mfcxx.dll.

	FastCopy is GPLv3 license, you can modify and use under GPLv3

License:
	-------------------------------------------------------------------------
	 FastCopy ver4.x
	 Copyright(C) 2004-2022 SHIROUZU Hiroaki All rights reserved.
	 Copyright(C) 2018-2022 FastCopy Lab, LLC. All rights reserved.

	  Due to various circumstances, distribution of the source code is
	   temporarily suspended.
	  Please use FastCopy as freeware with no guarantee.
	-------------------------------------------------------------------------

	xxHash library Copyright (C) 2012-2021 Mr.Yann Collet, All rights reserved.
	  more details: doc/xxhash-LICENSE.txt

	OpenSSL library Copyright (C) 1998-2021 The OpenSSL Project,
	  All rights reserved. more details: doc/apache-license-2.0.txt

Usage：
	Please see fastcopy_eng.htm

Build:
	VS2022 or later

