
Language=Russian (Россия)
Product=FileMenu Tools
Version=8.1.0.0
LastUpdated=230314
Author=wvxwxvw

https://github.com/wvxwxvw/translation