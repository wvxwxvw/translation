
Language=Russian (Россия)
Product=FileMenu Tools
Version=8.0.2.0
LastUpdated=230125
Author=wvxwxvw

https://github.com/wvxwxvw/translation