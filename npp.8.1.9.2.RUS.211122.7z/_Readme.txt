
<!--
	Russian localization for Notepad++ 8.1.9.1
	last modified: 211115
		Нет раздражающего сКаКаНиЯ ТеКсТа и лишних символов.
		В комплекте, выравненные с русским, английский и немецкий
-->

Перевод contextMenu от DmitryFedorov, дополнил, убрал
сКаКаНиЕ ТеКсТа и привел в соответствие со своим переводом.

https://github.com/wvxwxvw/translation